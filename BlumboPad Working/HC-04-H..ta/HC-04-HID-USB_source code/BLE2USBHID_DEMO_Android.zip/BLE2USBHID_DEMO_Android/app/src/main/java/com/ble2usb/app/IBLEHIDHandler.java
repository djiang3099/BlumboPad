package com.ble2usb.app;

public interface IBLEHIDHandler {

    void onMessage(String msg);


}